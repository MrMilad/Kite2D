/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef KAUDIO_H
#define KAUDIO_H

#include <string.h>
#include "Kite/system/kdefinitions.h"
#include "Kite/system/ktypes.h"
#include "Kite/audio/kaudiotypes.h"
#include "Kite/audio/kaudiostructs.h"

namespace Kite{
    class KAudio{
    public:
        KAudio() {}
        virtual ~KAudio() {}

        virtual bool initialize(const KAudioState &state) = 0;
        virtual void release() = 0;

//        void setListener(const KAudioListener &listener);
//        KAudioListener getListener();

        /* General Propertiec */
        virtual bool setMasterGain(F32 gain = 1.00f) = 0; // 0.0f to 1.0f
        virtual F32 getMasterGain() const = 0;// {return m_gain;}

        /* Create/Destroy Player*/
        virtual bool generatePlayer(KAudioPlayer &Player) = 0;
        virtual bool destroyPlayer(KAudioPlayer &Player) = 0;

        /* Load file */
        virtual bool playerReloadFile(KAudioPlayer &Player, std::string &FileName,
                            KAudioLoadTypes LoadType) = 0; // Delete Buffer and Create New buffer

        /* Player Options */
        virtual bool playerSetPropertiec(const KAudioPlayer &Player,
                                         const KAudioPlayerPropertiec &Propertiec,
                                         U16 Types) = 0; // Types = KAudioPropertiesTypes
        virtual bool playerGetPropertiec(const KAudioPlayer &Player,
                                         KAudioPlayerPropertiec &Propertiec) = 0;
        virtual KAudioPlayerStateTypes playerGetState(const KAudioPlayer &Player) = 0;
        virtual bool playerGetDataPropertiec(const KAudioPlayer &Player,
                                                   KAudioDataProperty &DataProperty) = 0;


        /* Player Operations */
        virtual bool playerPlay(const KAudioPlayer &Player) = 0;
        virtual void playerStop(const KAudioPlayer &Player) = 0;
        virtual void playerPause(const KAudioPlayer &Player) = 0;
        virtual KiteErrorTypes GetLastError() = 0;

    };

    extern KAudio *CreateAudio(); // not exported in dll (this must calling only by engine not user)
    extern void DestroyAudio(); // not exported in dll (this must calling only by engine not user)
}

#endif // KAUDIO_H
