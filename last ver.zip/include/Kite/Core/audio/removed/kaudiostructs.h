/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef KAUDIOSTRUCTS_H
#define KAUDIOSTRUCTS_H

#include <vector>
#include <string>
#include "Kite/system/ksystemdef.h"
#include "Kite/audio/kaudiotypes.h"

namespace Kite{

//    struct KAudioDevice{
//        bool isDefault, efxSupport;
//        U8 id;
//        std::string name;
//        KAudioDevice(bool Default = true, bool Efx = false,
//                     U8 Id = 0, std::string Name = ""):
//            isDefault(Default), efxSupport(Efx),
//            id(Id), name(Name)
//        {}
//    };

//    typedef KAudioDevice KAudioState;

//    struct KAudioDeviceCaps{
//        bool reverb, eaxReverb, chorus, distortion, echo, flanger,
//            frequencyShifter, vocalMorpher, pitchShifter, ringModulator, autowah, compressor,
//            equalizer, lowPassFilter, highPassFilter, bandPassFilter;
//        U16 auxiliaryEffectSlots, auxiliarySendsSlots;

//        KAudioDeviceCaps(bool Rev = false, bool EaxReverb = false, bool Chor = false, bool Distort = false, bool Echo = false,
//                         bool Flang = false, bool FrqShift = false, bool VocMorph = false, bool PitchShift = false,
//                         bool RingMod = false, bool Autow = false, bool Comp = false, bool Equ = false, bool LowPas = false,
//                         bool HighPas = false, bool BandPas = false,
//                         U16 AuxiliaryEffect = 0, U16 AuxiliarySends = 0):
//            reverb(Rev), eaxReverb(EaxReverb), chorus(Chor),
//            distortion(Distort), echo(Echo), flanger(Flang),
//            frequencyShifter(FrqShift), vocalMorpher(VocMorph),
//            pitchShifter(PitchShift), ringModulator(RingMod),
//            autowah(Autow), compressor(Comp), equalizer(Equ),
//            lowPassFilter(LowPas), highPassFilter(HighPas),
//            bandPassFilter(BandPas), auxiliaryEffectSlots(AuxiliaryEffect), auxiliarySendsSlots(AuxiliarySends)
//        {}
//    };

//    struct KEnumAudio{
//            KAudioDevice device;
//            KAudioDeviceCaps deviceCaps;

//            KEnumAudio(KAudioDevice Device = KAudioDevice(), KAudioDeviceCaps DeviceCaps = KAudioDeviceCaps()):
//                device(Device), deviceCaps(DeviceCaps)
//            {}
//    };

//    typedef std::vector<KEnumAudio> KEnumAudioList;

//    struct KAudioListener{
//        U32 gain;
//        F32 xPosition, yPosition, zPosition;
//        F32 xVelocity, yVelocity, zVelocity;
//        F32 xOrientation1, yOrientation1, zOrientation1,
//            xOrientation2, yOrientation2, zOrientation2;

//        KAudioListener(U32 Gain = 1,
//                        F32 Xposition = 0.0f, F32 Yposition = 0.0f, F32 Zposition = 0.0f,
//                        F32 Xvelocity = 0.0f, F32 Yvelocity = 0.0f, F32 Zvelocity = 0.0f,
//                        F32 Xorientation1 = 0.0f, F32 Yorientation1 = 0.0f, F32 Zorientation1 = 0.0f,
//                        F32 Xorientation2 = 0.0f, F32 Yorientation2 = 0.0f, F32 Zorientation2 = 0.0f):
//            gain(Gain), xPosition(Xposition), yPosition(Yposition), zPosition(Zposition),
//            xVelocity(Xvelocity), yVelocity(Yvelocity), zVelocity(Zvelocity),
//            xOrientation1(Xorientation1), yOrientation1(Yorientation1), zOrientation1(Zorientation1),
//            xOrientation2(Xorientation2), yOrientation2(Yorientation2), zOrientation2(Zorientation2)
//        {}
//    };

//    struct KAudioPlayer{
//        friend class KAudioImpl;
//        KAudioPlayer(KASOURCE Source = 0, KABUFFER Buffer = 0,
//                     KAudioLoadTypes LoadType = KAUDIO_LOAD_STATIC):
//            source(Source), buffer(Buffer),
//            loadTypes(LoadType)
//        {}
//    private:
//        std::string fileName;
//        KASOURCE source;
//        KABUFFER buffer;
//        KAudioLoadTypes loadTypes;

//    };

//    // Only standard options in OpenAL (EFX option in oter version)
//    struct KAudioPlayerPropertiec{
//        F32 gain; // 0.0f to 1.0f+ always positive
//        F32 pitch; // Range [0.5 to 2.0]
//        F32 pan; // Range [-1.0f to 1.0f]
//        bool loop;

//        KAudioPlayerPropertiec(F32 Gain = 1.00f, F32 Pitch = 1.00f, F32 Pan = 0, bool Loop = false):
//            gain(Gain), pitch(Pitch),
//            pan(Pan), loop(Loop)
//        {}
//    };

//    struct KAudioDataProperty{
//        I32 frequency, bits, channels, size;

//        KAudioDataProperty(I32 Frequency = 0, I32 Bits = 0,
//                           I32 Channels = 0, I32 Size = 0):
//            frequency(Frequency), bits(Bits),
//            channels(Channels), size(Size)
//        {}
//    };

//    struct KAudioState{
//        const KAudioDevice *device;

//        KAudioState(const KAudioDevice *mDevice = 0):
//            device(mDevice)
//        {}
//    };

}

#endif // KAUDIOSTRUCTS_H
