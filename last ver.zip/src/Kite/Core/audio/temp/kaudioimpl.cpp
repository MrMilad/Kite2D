/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "Kite/audio/kaudioimpl.h"
#include "Kite/audio/oalefxfp.h"

namespace Kite{
    //CWaves KAudioImpl::m_waveLoader;
    std::vector<KAudioDeviceCaps> KAudioImpl::m_audioCaps;
    bool KAudioImpl::m_isInitAudio = false;
    KAudioImpl *KAudioImpl::m_audioImpl = 0;

    KAudioImpl::KAudioImpl():
        KAudio(),
        m_context(0), m_device(0), m_gain(1),
        m_sourceCount(0), m_bufferCount(0),
        m_lastError(KERROR_OK)
    {}

    bool KAudioImpl::initialize(const KAudioState &state){
        if (m_isInitAudio){
            KDEBUG_PRINT("Message: Audio object was initialized before")
            m_lastError = KERROR_CREATED;
            return true;
        }

        // check for device type (default)
        const ALchar *dName = NULL;
        if (!state.isDefault){
            dName = state.name.c_str();
        }

        // open audio device
        m_device = alcOpenDevice(dName);
        if (!m_device){
            KDEBUG_PRINT("API Fail: alcOpenDevice()")
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        // create context and set as current context
        m_context = alcCreateContext(m_device,NULL);
        if (!m_context){
            KDEBUG_PRINT("API Fail: alcCreateContext()")
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        alcMakeContextCurrent(m_context);

        alGetError();
        m_isInitAudio = true;
        return true;
    }

    void KAudioImpl::release(){
        m_isInitAudio = false;
        alcMakeContextCurrent(NULL);
        alcDestroyContext(m_context);
        alcCloseDevice(m_device);
    }

//    void KAudioImpl::setListener(const KAudioListener &listener){
//        m_gain = listener.gain;

//        m_listenerPos[0] = listener.xPosition;
//        m_listenerPos[1] = listener.yPosition;
//        m_listenerPos[2] = listener.zPosition;

//        m_listenerVel[0] = listener.xVelocity;
//        m_listenerVel[1] = listener.yVelocity;
//        m_listenerVel[2] = listener.zVelocity;

//        m_listenerOri[0] = listener.xOrientation1;
//        m_listenerOri[1] = listener.yOrientation1;
//        m_listenerOri[2] = listener.zOrientation1;
//        m_listenerOri[3] = listener.xOrientation2;
//        m_listenerOri[4] = listener.yOrientation2;
//        m_listenerOri[5] = listener.zOrientation2;
//    }

//    KAudioListener KAudioImpl::getListener(){
//        return KAudioListener(m_gain, m_listenerPos[0], m_listenerPos[1], m_listenerPos[2],
//                              m_listenerVel[0], m_listenerVel[1], m_listenerVel[2],
//                              m_listenerOri[0], m_listenerOri[1], m_listenerOri[2],
//                              m_listenerOri[3], m_listenerOri[4], m_listenerOri[5]);
//    }

    const KAudioDeviceCaps *getAudioDeviceCaps(const KAudioDevice &Device){
        if (KAudioImpl::m_audioCaps.size() <= Device.id){
            KDEBUG_PRINT("Message: device list is empty")
//            m_lastError = KERROR_INVALIDLIST;
            return 0;
        }

        return &KAudioImpl::m_audioCaps.at(Device.id);
    }

    bool KAudioImpl::setMasterGain(F32 gain){
        if (!m_isInitAudio) return false;

        if (gain > 5) gain = 5.0f;
        if (gain < 0) gain = 0.0f;
        alGetError();
        alListenerf(AL_GAIN, (ALfloat)gain);
        if (alGetError() != AL_NO_ERROR){
            KDEBUG_PRINT("API Fail: alListenerf()")
            m_lastError = KERROR_APIFAIL;
            return false;
        }
        m_gain = gain;
        return true;
    }

    bool KAudioImpl::generatePlayer(KAudioPlayer &Player){
        if (!m_isInitAudio){
            m_lastError = KERROR_UNINITIALIZED;
            return false;
        }

        // generate an openal source
        ALuint source;
        alGetError();
        alGenSources(1, &source);
        if (alGetError() != AL_NO_ERROR){
            KDEBUG_PRINT("API Fail: alGenSources()")
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        // Set necessary source propertiec
        alSourcei(source, AL_SOURCE_RELATIVE, AL_TRUE);
        alSourcei(source, AL_REFERENCE_DISTANCE, 0);
        alSourcei(source, AL_MAX_DISTANCE, 0);
        alSourcei(source, AL_MIN_GAIN, 0);
        alSourcei(source, AL_MAX_GAIN, 1);

        ++m_sourceCount;
        Player.source = source;

        return true;
    }

    bool KAudioImpl::destroyPlayer(KAudioPlayer &Player){
        if (!m_isInitAudio){
            m_lastError = KERROR_UNINITIALIZED;
            return 0;
        }

        alSourceStop((ALuint) Player.source);
        alGetError();
        alSourcei((ALuint) Player.source, AL_BUFFER, 0);
        alDeleteSources(1, (const ALuint *) &Player.source);
        alDeleteBuffers(1, (const ALuint *) &Player.buffer);
        if (alGetError() != AL_NO_ERROR){
            KDEBUG_PRINT("Message: can't unload player")
            m_lastError = KERROR_APIFAIL;
            return false;
        }
        Player.source = 0;
        Player.buffer = 0;
        return true;
    }

    bool KAudioImpl::playerReloadFile(KAudioPlayer &Player,
                                  std::string &FileName,
                                  KAudioLoadTypes LoadType){
        if (!m_isInitAudio){
            m_lastError = KERROR_UNINITIALIZED;
            return false;
        }

        // delete existing buffer
        alSourceStop((ALuint) Player.source);
        alSourcei((ALuint) Player.source, AL_BUFFER, 0);
        if (alIsBuffer((ALuint) Player.buffer) == AL_TRUE){
            alDeleteBuffers(1, (const ALuint *) &Player.buffer);
            --m_bufferCount;
        }

        // generate an new buffer
        ALuint buffer;
        alGetError();
        alGenBuffers( 1, &buffer);
        if (alGetError() != AL_NO_ERROR){
            KDEBUG_PRINT("API Fail: alGenBuffers()")
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        switch(LoadType){
        case KAUDIO_LOAD_STATIC:
            // load wave file into openal buffer
            if (!_loadWaveToBuffer(FileName.c_str(), buffer)){
                KDEBUG_PRINT("Message: can't load audio file")
                m_lastError = KERROR_CANTLOADFILE;
                break;
            }

            // attach new buffer to source
            alSourcei((ALuint) Player.source, AL_BUFFER, buffer);
            if (alGetError() != AL_NO_ERROR){
                KDEBUG_PRINT("Message: can't attach buffer to source")
                m_lastError = KERROR_APIFAIL;
                break;
            }
            Player.fileName = FileName;
            Player.buffer = buffer;
            ++m_bufferCount;
            return true;
        case KAUDIO_LOAD_STREAM: // stream loading .... coming soon!
            break;
        }

        // Error: Clean buffer
        alDeleteBuffers(1, &buffer);
        return false;
    }

    bool KAudioImpl::playerSetPropertiec(const KAudioPlayer &Player,
                                         const KAudioPlayerPropertiec &Propertiec,
                                         U16 Types){

        if (!m_isInitAudio){
            m_lastError = KERROR_UNINITIALIZED;
            return false;
        }

        alGetError();
        if (Types & KAUDIO_PROP_GAIN) // set gain
            alSourcef((ALuint)Player.source, AL_GAIN, (ALfloat)Propertiec.gain);

        if (Types & KAUDIO_PROP_PITCH) // set pitch
            alSourcef((ALuint)Player.source, AL_PITCH, (ALfloat)Propertiec.pitch);

        if (Types & KAUDIO_PROP_PAN) // set pan
            alSource3f((ALuint)Player.source, AL_POSITION, (ALfloat)Propertiec.pan, 0.0f, 0.0f);

        if (Types & KAUDIO_PROP_LOOP){ // loop
            if (Propertiec.loop){
                alSourcei((ALuint)Player.source, AL_LOOPING, AL_TRUE);
            }else{
                alSourcei((ALuint)Player.source, AL_LOOPING, AL_FALSE);
            }
        }

        // Checking ...
        if (alGetError() != AL_NO_ERROR){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: can't set player propertiec. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_lastError = KERROR_APIFAIL;
            return false;
        }
        return true;
    }

    bool KAudioImpl::playerGetPropertiec(const KAudioPlayer &Player,
                                     KAudioPlayerPropertiec &Propertiec){
        if (!m_isInitAudio){
            m_lastError = KERROR_UNINITIALIZED;
            return false;
        }

        ALint iVal;
        ALfloat fVal1;
        ALfloat fVal2;
        ALfloat fVal3;
        alGetError();
        alGetSourcei((ALuint)Player.source, AL_LOOPING, &iVal);
        if (iVal == AL_TRUE){
            Propertiec.loop = true;
        }else{
            Propertiec.loop = false;
        }
        alGetSourcef((ALuint)Player.source, AL_PITCH, (ALfloat *)&Propertiec.pitch);
        alGetSourcef((ALuint)Player.source, AL_GAIN, (ALfloat *)&Propertiec.gain);
        alGetSource3f((ALuint)Player.source, AL_POSITION, &fVal1, &fVal2, &fVal3);
        Propertiec.pan = fVal1;

        if (alGetError() != AL_NO_ERROR){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: can't get player propertiec. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_lastError = KERROR_APIFAIL;
            return false;
        }
        return true;
    }

    KAudioPlayerStateTypes KAudioImpl::playerGetState(const KAudioPlayer &Player){

        if (!m_isInitAudio){
            m_lastError = KERROR_UNINITIALIZED;
            return KAUDIO_PLAYER_CANTRET;
        }

        ALint iVal;
        alGetError();
        alGetSourcei((ALuint)Player.source, AL_SOURCE_STATE, &iVal);
        if (alGetError() != AL_NO_ERROR){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: can't get player state. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_lastError = KERROR_APIFAIL;
            return KAUDIO_PLAYER_CANTRET;
        }

        switch(iVal){
        case AL_INITIAL:
            return KAUDIO_PLAYER_INTIAL;
        case AL_PLAYING:
            return KAUDIO_PLAYER_PLAYING;
        case AL_PAUSED:
            return KAUDIO_PLAYER_PAUSED;
        case AL_STOPPED:
            return KAUDIO_PLAYER_STOPPED;
        }
        return KAUDIO_PLAYER_CANTRET;
    }

    bool KAudioImpl::playerGetDataPropertiec(const KAudioPlayer &Player,
                                         KAudioDataProperty &DataProperty){

        if (!m_isInitAudio){
            m_lastError = KERROR_UNINITIALIZED;
            return false;
        }

        if (alIsBuffer((ALuint)Player.buffer) == AL_FALSE){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: invalid buffer. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_lastError = KERROR_INVALIDBUFFER;
            return false;
        }

        // Retriev properties
        alGetBufferi((ALuint)Player.buffer, AL_FREQUENCY, (ALint *) &DataProperty.frequency);
        alGetBufferi((ALuint)Player.buffer, AL_BITS, (ALint *) &DataProperty.bits);
        alGetBufferi((ALuint)Player.buffer, AL_CHANNELS, (ALint *) &DataProperty.channels);
        alGetBufferi((ALuint)Player.buffer, AL_SIZE, (ALint *) &DataProperty.size);

        return true;
    }

    bool KAudioImpl::playerPlay(const KAudioPlayer &Player){

        alGetError();
        switch(Player.loadTypes){
        case KAUDIO_LOAD_STATIC:
            alSourcePlay((ALuint)Player.source);
            break;
        case KAUDIO_LOAD_STREAM:
            break;
        }

        if (alGetError() != AL_NO_ERROR){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: can't play. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_lastError = KERROR_APIFAIL;
            return false;
        }
        return true;
    }

    void KAudioImpl::playerStop(const KAudioPlayer &Player){

        alGetError();
        switch(Player.loadTypes){
        case KAUDIO_LOAD_STATIC:
            alSourceStop((ALuint)Player.source);
            break;
        case KAUDIO_LOAD_STREAM:
            break;
        }

        if (alGetError() != AL_NO_ERROR){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: can't stop. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_lastError = KERROR_APIFAIL;
        }
    }

    void KAudioImpl::playerPause(const KAudioPlayer &Player){
        alGetError();
        switch(Player.loadTypes){
        case KAUDIO_LOAD_STATIC:
            alSourcePause((ALuint)Player.source);
            break;
        case KAUDIO_LOAD_STREAM:
            break;
        }

        if (alGetError() != AL_NO_ERROR){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: can't stop. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_lastError = KERROR_APIFAIL;
        }
    }

    KiteErrorTypes KAudioImpl::GetLastError(){
        KiteErrorTypes temp = m_lastError;
        m_lastError = KERROR_OK;
        return temp;
    }

    bool KAudioImpl::_loadWaveToBuffer(const char *file, const U32 bufferId){
//        WAVEID WaveID;
//        ALint iDataSize, iFrequency;
//        ALenum eBufferFormat;
//        ALchar *pData = 0;
//        bool bRes = true;
//        alGetError();
//        if (SUCCEEDED(m_waveLoader.LoadWaveFile(file, &WaveID))){
//            if ((SUCCEEDED(m_waveLoader.GetWaveSize(WaveID, (unsigned long*)&iDataSize))) &&
//                (SUCCEEDED(m_waveLoader.GetWaveData(WaveID, (void**)&pData))) &&
//                (SUCCEEDED(m_waveLoader.GetWaveFrequency(WaveID, (unsigned long*)&iFrequency))) &&
//                (SUCCEEDED(m_waveLoader.GetWaveALBufferFormat(WaveID, &alGetEnumValue, (unsigned long*)&eBufferFormat)))){

//                alBufferData(bufferId, eBufferFormat, pData, iDataSize, iFrequency);
//                if (alGetError() != AL_NO_ERROR){
//                    #ifdef KITE_DEV_DEBUG
//                    printf("Error in: alBufferData api. |Line: %u |File: %s\n", __LINE__, __FILE__);
//                    #endif
//                    bRes = false;
//                }

//                // clean up
//                m_waveLoader.DeleteWaveFile(WaveID);
//            }else{
//                #ifdef KITE_DEV_DEBUG
//                printf("Error in: can't read waves file info. |Line: %u |File: %s\n", __LINE__, __FILE__);
//                #endif
//                bRes = false;
//            }
//        }else{
//            #ifdef KITE_DEV_DEBUG
//            printf("Error in: can't load waves file. |Line: %u |File: %s\n", __LINE__, __FILE__);
//            #endif
//            bRes = false;
//        }

//        return bRes;
        return false;
    }

    KAudio *KAudioImpl::_createInstance(){
        if (m_audioImpl != 0){
            #ifdef KITE_DEV_DEBUG
            printf("Message: an audio instance already exists. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            return (KAudio *)m_audioImpl;
        }
        m_audioImpl = new KAudioImpl();
        return (KAudio *)m_audioImpl;
    }

    void KAudioImpl::_destroyInstance(){
        if(m_isInitAudio){
            try{
                m_audioImpl->release();// maybe crash!
            }catch(...){}
        }
        delete m_audioImpl;
        m_audioImpl = 0;
    }

    KAudio *CreateAudio(){
        return KAudioImpl::_createInstance();
    }

    void DestroyAudio(){
        KAudioImpl::_destroyInstance();
    }
}
