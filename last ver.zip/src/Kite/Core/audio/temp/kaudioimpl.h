/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef KAUDIOIMPL_H
#define KAUDIOIMPL_H

#include <vector>
#include <cstdio>
#include <oal/al.h>
#include <oal/alc.h>
#include "libsndfile/win32/sndfile.h"
#include "Kite/audio/kaudioutil.h"
#include "Kite/audio/kaudio.h"

namespace Kite{
    class KAudioImpl : public KAudio{
    public:
//        virtual static KAudioImpl *CreateAudio();
//        virtual static void DestroyAudio();

        virtual bool initialize(const KAudioState &state);
        virtual void release();

//        void setListener(const KAudioListener &listener);
//        KAudioListener getListener();

        /* General Propertiec */
        virtual bool setMasterGain(F32 gain = 1.00f); // 0.0f to 1.0f
        virtual F32 getMasterGain() const {return m_gain;}

        /* Create/Destroy Player*/
        virtual bool generatePlayer(KAudioPlayer &Player);
        virtual bool destroyPlayer(KAudioPlayer &Player);

        /* Load file */
        virtual bool playerReloadFile(KAudioPlayer &Player, std::string &FileName,
                            KAudioLoadTypes LoadType); // Delete Buffer and Create New buffer

        /* Player Options */
        virtual bool playerSetPropertiec(const KAudioPlayer &Player,
                                        const KAudioPlayerPropertiec &Propertiec,
                                         U16 Types);
        virtual bool playerGetPropertiec(const KAudioPlayer &Player,
                                        KAudioPlayerPropertiec &Propertiec);
        virtual KAudioPlayerStateTypes playerGetState(const KAudioPlayer &Player);
        virtual bool playerGetDataPropertiec(const KAudioPlayer &Player,
                                                   KAudioDataProperty &DataProperty);


        /* Player Operations */
        virtual bool playerPlay(const KAudioPlayer &Player);
        virtual void playerStop(const KAudioPlayer &Player);
        virtual void playerPause(const KAudioPlayer &Player);
        virtual KiteErrorTypes GetLastError();

        // (internal use only)
        static KAudio *_createInstance();
        static void _destroyInstance();

        //static bool _iniFuncPointer(ALCdevice* pDevice);
        static bool _loadWaveToBuffer(const char *file,const U32 bufferId);
        static std::vector<KAudioDeviceCaps> m_audioCaps;

        /* OpenAL Objects */
        ALCcontext *m_context;
        ALCdevice *m_device;
        I32 m_gain;

        /* Counters */
        U16 m_sourceCount;
        U16 m_bufferCount;

        KiteErrorTypes m_lastError; // Stored last error

//        ALfloat m_listenerPos[3];
//        ALfloat m_listenerVel[3];
//        ALfloat m_listenerOri[6];

        static KAudioImpl *m_audioImpl; // Returned in _createInstance() and deleted in _destroyInstance()
        // static CWaves m_waveLoader;

    private:
        KAudioImpl();
        ~KAudioImpl(){}

        static bool m_isInitAudio;

    };
}
#endif // KAUDIOIMPL_H
