/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "Kite/audio/kaudioutil.h"
#include "Kite/system/kdefinitions.h"
#include "Kite/audio/oalefxfp.h"
#include <cstdio>
#include <string.h>

//    #if EAX_AVAILABLE
//    // EAX
//    if (AlExtEax = (alIsExtensionPresent("EAX") == AL_TRUE)){
//        eaxSet = (EAXSet)alGetProcAddress("EAXSet");
//        eaxGet = (EAXGet)alGetProcAddress("EAXGet");
//        if (!eaxSet || !eaxGet){
//            nlwarning("AL: EAX alGetProcAddress failed");
//            AlExtEax = false;
//        }
//    }
//    #endif

//    // EAX-RAM
//    if (alIsExtensionPresent("EAX-RAM") == AL_TRUE
//    || alIsExtensionPresent("EAX_RAM") == AL_TRUE){
//        eaxSetBufferMode = (EAXSetBufferMode)alGetProcAddress("EAXSetBufferMode");
//        eaxGetBufferMode = (EAXGetBufferMode)alGetProcAddress("EAXGetBufferMode");
////        if (!eaxSetBufferMode || !eaxGetBufferMode){
////        nlwarning("AL: EAX-RAM alGetProcAddress failed");
////        AlExtXRam = false;
////        }
//    }

namespace Kite{
    bool _EFXInit(ALCdevice *device){

        // retrieve EFX function pointers (if EFX available)
        static bool EFX_INIT = false;
        if (alcIsExtensionPresent(device, "ALC_EXT_EFX") == ALC_TRUE){
            // effect objects
            alGenEffects = (LPALGENEFFECTS)alGetProcAddress("alGenEffects");
            alDeleteEffects = (LPALDELETEEFFECTS)alGetProcAddress("alDeleteEffects");
            alIsEffect = (LPALISEFFECT)alGetProcAddress("alIsEffect");
            alEffecti = (LPALEFFECTI)alGetProcAddress("alEffecti");
            alEffectiv = (LPALEFFECTIV)alGetProcAddress("alEffectiv");
            alEffectf = (LPALEFFECTF)alGetProcAddress("alEffectf");
            alEffectfv = (LPALEFFECTFV)alGetProcAddress("alEffectfv");
            alGetEffecti = (LPALGETEFFECTI)alGetProcAddress("alGetEffecti");
            alGetEffectiv = (LPALGETEFFECTIV)alGetProcAddress("alGetEffectiv");
            alGetEffectf = (LPALGETEFFECTF)alGetProcAddress("alGetEffectf");
            alGetEffectfv = (LPALGETEFFECTFV)alGetProcAddress("alGetEffectfv");
            // effect objects
            alGenFilters = (LPALGENFILTERS)alGetProcAddress("alGenFilters");
            alDeleteFilters = (LPALDELETEFILTERS)alGetProcAddress("alDeleteFilters");
            alIsFilter = (LPALISFILTER)alGetProcAddress("alIsFilter");
            alFilteri = (LPALFILTERI)alGetProcAddress("alFilteri");
            alFilteriv = (LPALFILTERIV)alGetProcAddress("alFilteriv");
            alFilterf = (LPALFILTERF)alGetProcAddress("alFilterf");
            alFilterfv = (LPALFILTERFV)alGetProcAddress("alFilterfv");
            alGetFilteri = (LPALGETFILTERI)alGetProcAddress("alGetFilteri");
            alGetFilteriv = (LPALGETFILTERIV)alGetProcAddress("alGetFilteriv");
            alGetFilterf = (LPALGETFILTERF)alGetProcAddress("alGetFilterf");
            alGetFilterfv = (LPALGETFILTERFV)alGetProcAddress("alGetFilterfv");
            // submix objects
            alGenAuxiliaryEffectSlots = (LPALGENAUXILIARYEFFECTSLOTS)alGetProcAddress("alGenAuxiliaryEffectSlots");
            alDeleteAuxiliaryEffectSlots = (LPALDELETEAUXILIARYEFFECTSLOTS)alGetProcAddress("alDeleteAuxiliaryEffectSlots");
            alIsAuxiliaryEffectSlot = (LPALISAUXILIARYEFFECTSLOT)alGetProcAddress("alIsAuxiliaryEffectSlot");
            alAuxiliaryEffectSloti = (LPALAUXILIARYEFFECTSLOTI)alGetProcAddress("alAuxiliaryEffectSloti");
            alAuxiliaryEffectSlotiv = (LPALAUXILIARYEFFECTSLOTIV)alGetProcAddress("alAuxiliaryEffectSlotiv");
            alAuxiliaryEffectSlotf = (LPALAUXILIARYEFFECTSLOTF)alGetProcAddress("alAuxiliaryEffectSlotf");
            alAuxiliaryEffectSlotfv = (LPALAUXILIARYEFFECTSLOTFV)alGetProcAddress("alAuxiliaryEffectSlotfv");
            alGetAuxiliaryEffectSloti = (LPALGETAUXILIARYEFFECTSLOTI)alGetProcAddress("alGetAuxiliaryEffectSloti");
            alGetAuxiliaryEffectSlotiv = (LPALGETAUXILIARYEFFECTSLOTIV)alGetProcAddress("alGetAuxiliaryEffectSlotiv");
            alGetAuxiliaryEffectSlotf = (LPALGETAUXILIARYEFFECTSLOTF)alGetProcAddress("alGetAuxiliaryEffectSlotf");
            alGetAuxiliaryEffectSlotfv = (LPALGETAUXILIARYEFFECTSLOTFV)alGetProcAddress("alGetFilterfv");
            if (!alGenEffects || !alGenFilters || !alGenAuxiliaryEffectSlots){
                KDEBUG_PRINT("Message: cant initialize EFX")
                return false;
            }
            EFX_INIT = true;
            return true;
        }
        KDEBUG_PRINT("Message: current audio device not support EFX")
        return false;
    }

    const KEnumAudioList *getAudioDevicesList(){
        static KEnumAudioList AudioDeviceList;
        ALuint iDeviceIndex = 0;
        const char *pDeviceNames = NULL;
        const char *pDefaultDevice = NULL;
        ALuint uiEffectSlots[128] = { 0 };
        ALint iEffectSlotsGenerated = 0;
        ALuint uiEffects = 0;
        ALuint uiFilters = 0;
        ALint iSends = 0;
        bool bRes = true;

        AudioDeviceList.clear();
        if (!alcIsExtensionPresent(NULL, "ALC_ENUMERATION_EXT")){
            KDEBUG_PRINT("Message: cant enumeration audio device")
            return 0;
        }

        // retrive device(s) name
        pDeviceNames = alcGetString( NULL, ALC_DEVICE_SPECIFIER ); // all device
        pDefaultDevice = alcGetString( NULL, ALC_DEFAULT_DEVICE_SPECIFIER ); // default device

        // audio device not found
        if( !strlen(pDeviceNames) ){
            KDEBUG_PRINT("Message: none audio device fonded")
    //      m_lastError = KERROR_APIFAIL;
            return 0;
        }

        while( pDeviceNames && *pDeviceNames ){
            KEnumAudio m_enumAudio;
            bool isDefault = false;
            bool isEFXSupport = false;

            // open and query for extensions (capabilities)
            ALCdevice* pDevice = alcOpenDevice(pDeviceNames);
            if(pDevice){

                ALCcontext* Context=alcCreateContext(pDevice,NULL);
                if (Context){
                    alcMakeContextCurrent(Context);
                    // check for efx support
                    if (_EFXInit(pDevice)){
                        isEFXSupport = true;

                        // To determine how many Auxiliary Effects Slots are available
                        // create as many as possible (up to 128)
                        // until the call fails.
                        for (iEffectSlotsGenerated = 0; iEffectSlotsGenerated < 128; iEffectSlotsGenerated++)
                        {
                            alGenAuxiliaryEffectSlots(1, &uiEffectSlots[iEffectSlotsGenerated]);
                            if (alGetError() != AL_NO_ERROR)
                                break;
                        }
                        m_enumAudio.deviceCaps.auxiliaryEffectSlots = iEffectSlotsGenerated;

                        // Retrieve the number of Auxiliary Effect Slots Sends available on each Source
                        alcGetIntegerv(pDevice, ALC_MAX_AUXILIARY_SENDS, 1, &iSends);
                        m_enumAudio.deviceCaps.auxiliarySendsSlots = iSends;

                        // To determine which Effects are supported, generate an Effect Object, and try to set its type to
                        // the various Effect enum values
                        alGenEffects(1, &uiEffects);
                        if (alGetError() == AL_NO_ERROR){

                            // try setting effect type to known effects
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_REVERB);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.reverb = true; else m_enumAudio.deviceCaps.reverb = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_EAXREVERB);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.eaxReverb = true; else m_enumAudio.deviceCaps.eaxReverb = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_CHORUS);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.chorus = true; else m_enumAudio.deviceCaps.chorus = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_DISTORTION);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.distortion = true; else m_enumAudio.deviceCaps.distortion = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_ECHO);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.echo = true; else m_enumAudio.deviceCaps.echo = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_FLANGER);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.flanger = true; else m_enumAudio.deviceCaps.flanger = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_FREQUENCY_SHIFTER);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.frequencyShifter = true; else m_enumAudio.deviceCaps.frequencyShifter = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_VOCAL_MORPHER);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.vocalMorpher = true; else m_enumAudio.deviceCaps.vocalMorpher = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_PITCH_SHIFTER);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.pitchShifter = true; else m_enumAudio.deviceCaps.pitchShifter = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_RING_MODULATOR);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.ringModulator = true; else m_enumAudio.deviceCaps.ringModulator = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_AUTOWAH);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.autowah = true; else m_enumAudio.deviceCaps.autowah = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_COMPRESSOR);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.compressor = true; else m_enumAudio.deviceCaps.compressor = false;
                            alEffecti(uiEffects, AL_EFFECT_TYPE, AL_EFFECT_EQUALIZER);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.equalizer = true; else m_enumAudio.deviceCaps.equalizer = false;
                        }

                        // Generate a Filter to use to determine what Filter Types are supported
                        alGenFilters(1, &uiFilters);
                        if (alGetError() == AL_NO_ERROR){
                            // Try setting the Filter type to known Filters
                            alFilteri(uiFilters, AL_FILTER_TYPE, AL_FILTER_LOWPASS);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.lowPassFilter = true; else m_enumAudio.deviceCaps.lowPassFilter = false;
                            alFilteri(uiFilters, AL_FILTER_TYPE, AL_FILTER_HIGHPASS);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.highPassFilter = true; else m_enumAudio.deviceCaps.highPassFilter = false;
                            alFilteri(uiFilters, AL_FILTER_TYPE, AL_FILTER_BANDPASS);
                            if (alGetError() == AL_NO_ERROR) m_enumAudio.deviceCaps.bandPassFilter = true; else m_enumAudio.deviceCaps.bandPassFilter = false;
                        }

                        AudioDeviceList.push_back(m_enumAudio);

                        // Delete Filter
                        alDeleteFilters(1, &uiFilters);
                        // Delete Effect
                        alDeleteEffects(1, &uiEffects);
                        // Delete Auxiliary Effect Slots
                        alDeleteAuxiliaryEffectSlots(iEffectSlotsGenerated, uiEffectSlots);
                    }

                    alcMakeContextCurrent(NULL);
                    alcDestroyContext(Context);
                }
                alcCloseDevice(pDevice);
            }else{
                KDEBUG_PRINT("Message: can't open the audio device")
                bRes = false;
            }

            // check for default device
            if (strcmp( pDeviceNames, pDefaultDevice) == 0)
                isDefault = true; // current device is default

            // add device to device(s) list
            AudioDeviceList[iDeviceIndex].device.isDefault = isDefault;
            AudioDeviceList[iDeviceIndex].device.efxSupport = isEFXSupport;
            AudioDeviceList[iDeviceIndex].device.id = iDeviceIndex;
            AudioDeviceList[iDeviceIndex].device.name = pDeviceNames;
            ++iDeviceIndex;
            pDeviceNames += strlen(pDeviceNames) + 1;
        }
        return &AudioDeviceList;
    }

}
