/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef OALEFXFP_H
#define OALEFXFP_H

#include <oal/al.h>
#include <oal/alc.h>
#include <oal/alext.h>
#include <oal/efx.h>

// Effect objects
static LPALGENEFFECTS alGenEffects = 0;
static LPALDELETEEFFECTS alDeleteEffects = 0;
static LPALISEFFECT alIsEffect = 0;
static LPALEFFECTI alEffecti = 0;
static LPALEFFECTIV alEffectiv = 0;
static LPALEFFECTF alEffectf = 0;
static LPALEFFECTFV alEffectfv = 0;
static LPALGETEFFECTI alGetEffecti = 0;
static LPALGETEFFECTIV alGetEffectiv = 0;
static LPALGETEFFECTF alGetEffectf = 0;
static LPALGETEFFECTFV alGetEffectfv = 0;

//Filter objects
static LPALGENFILTERS alGenFilters = 0;
static LPALDELETEFILTERS alDeleteFilters = 0;
static LPALISFILTER alIsFilter = 0;
static LPALFILTERI alFilteri = 0;
static LPALFILTERIV alFilteriv = 0;
static LPALFILTERF alFilterf = 0;
static LPALFILTERFV alFilterfv = 0;
static LPALGETFILTERI alGetFilteri = 0;
static LPALGETFILTERIV alGetFilteriv = 0;
static LPALGETFILTERF alGetFilterf = 0;
static LPALGETFILTERFV alGetFilterfv = 0;

// Auxiliary slot object
static LPALGENAUXILIARYEFFECTSLOTS alGenAuxiliaryEffectSlots = 0;
static LPALDELETEAUXILIARYEFFECTSLOTS alDeleteAuxiliaryEffectSlots = 0;
static LPALISAUXILIARYEFFECTSLOT alIsAuxiliaryEffectSlot = 0;
static LPALAUXILIARYEFFECTSLOTI alAuxiliaryEffectSloti = 0;
static LPALAUXILIARYEFFECTSLOTIV alAuxiliaryEffectSlotiv = 0;
static LPALAUXILIARYEFFECTSLOTF alAuxiliaryEffectSlotf = 0;
static LPALAUXILIARYEFFECTSLOTFV alAuxiliaryEffectSlotfv = 0;
static LPALGETAUXILIARYEFFECTSLOTI alGetAuxiliaryEffectSloti = 0;
static LPALGETAUXILIARYEFFECTSLOTIV alGetAuxiliaryEffectSlotiv = 0;
static LPALGETAUXILIARYEFFECTSLOTF alGetAuxiliaryEffectSlotf = 0;
static LPALGETAUXILIARYEFFECTSLOTFV alGetAuxiliaryEffectSlotfv = 0;

static bool _EFXInit(ALCdevice *device);

#endif // OALEFXFP_H
