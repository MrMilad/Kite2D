/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "Kite/graphic/kcolor.h"

namespace Kite{

    KColor::KColor(){
        color[KC_R] = 1;
        color[KC_G] = 1;
        color[KC_B] = 1;
        color[KC_A] = 1;
    }

    KColor::KColor(const KColor &color):
        r(color.r), g(color.g), b(color.b), a(color.a)
    {}

    KColor::KColor(U8 R, U8 G, U8 B, U8 A):
        r(R),g(G),b(B),a(A)
    {}

    // Operators
    bool operator ==(const KColor& left, const KColor& right){
        return (left.r == right.r) &&
               (left.g == right.g) &&
               (left.b == right.b) &&
               (left.a == right.a);
    }

    bool operator !=(const KColor& left, const KColor& right){
        return !(left == right);
    }

    KColor operator +(const KColor& left, const KColor& right){
        return KColor(static_cast<U8>(left.r + right.r, 255),
             static_cast<U8>(left.g + right.g, 255),
             static_cast<U8>(left.b + right.b, 255),
             static_cast<U8>(left.a + right.a, 255));
    }

    KColor operator *(const KColor& left, const KColor& right){
        return KColor(static_cast<U8>(left.r * right.r / 255),
             static_cast<U8>(left.g * right.g / 255),
             static_cast<U8>(left.b * right.b / 255),
             static_cast<U8>(left.a * right.a / 255));
    }

    KColor& operator +=(KColor& left, const KColor& right){
        return left = left + right;
    }

    KColor& operator *=(KColor& left, const KColor& right){
        return left = left * right;
    }

    // Utility
    void ARGBtoKCOLOR(KCOLOR& color, const KColor &rgba){
        color = (rgba.a << 24) | (rgba.r << 16) | (rgba.g << 8) | rgba.b;
    }

    void ARGBtoKCOLOR(KCOLOR& color, const U8 A, const U8 R, const U8 G, const U8 B){
        color = (A << 24) | (R << 16) | (G << 8) | B;
    }

    void KCOLORtoARGB(KColor &rgba, const KCOLOR &color){
        rgba.a = (color & 0xFF000000) >> 24;
        rgba.r = (color & 0x00FF0000) >> 16;
        rgba.g = (color & 0x0000FF00) >> 8;
        rgba.b = (color & 0x000000FF);
    }
}
