/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "Kite/graphic/win32/kgraphicimpl.h"
namespace Kite{
    KGraphicImpl *KGraphicImpl::m_GraphicImpl = 0;

    KGraphicImpl::KGraphicImpl() : KGraphic(){
        m_p3d = 0;
        m_dRender = 0;
        m_backbuffer = 0;
        m_sprHndFix = 0;
        m_sprHndTrn = 0;
        m_lastError = KERROR_OK;
        m_hWnd = 0;
        m_isIniteRender = false;
        m_deviceIsLost = false;
        m_useRotSprite = false;
        m_isErrorDuring = false;
    }

    KGraphicImpl::~KGraphicImpl(){}

    bool KGraphicImpl::initialize(const KWindowState &winState, KDisplayState disState, HWND hWindow){
        if (m_isIniteRender){
            #ifdef KITE_DEV_DEBUG
            printf("Result: renderer object was initialized before.\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return true;
        }
        // create direct3d 9 object
        m_p3d = Direct3DCreate9(D3D_SDK_VERSION);
        if (m_p3d == NULL){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: Direct3DCreate9 Api (creation direct3d object).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return false;
        }

        m_winState = winState;
        m_disState = disState;
        m_hWnd = hWindow;

        // get system desktop color depth
        D3DDISPLAYMODE dm;
        m_p3d->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &dm);

        // set configuration options for Direct3D
        ZeroMemory(&m_d3dpp, sizeof(m_d3dpp));
        m_d3dpp.Windowed = (!m_winState.getFullscreen());
        m_d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE; // 3D Cap.
        m_d3dpp.MultiSampleQuality = 0; // 3D Cap.
        m_d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
        m_d3dpp.EnableAutoDepthStencil = TRUE;
        m_d3dpp.AutoDepthStencilFormat = D3DFMT_D16;
        if (!m_disState.getVsync())
            m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;
        else{
            switch(m_disState.getPresentType()){
            case KPRESENT_INT_DEFAULT:
                m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
                break;
            case KPRESENT_INT_1:
                m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;
                break;
            case KPRESENT_INT_2:
                m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_TWO;
                break;
            case KPRESENT_INT_3:
                m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_THREE;
                break;
            case KPRESENT_INT_4:
                m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_FOUR;
                break;
            default:
                m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;
                break;
            }
        }
        m_d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
        m_d3dpp.Flags = 0;
        m_d3dpp.BackBufferFormat = dm.Format;
        m_d3dpp.BackBufferCount = 1;
        m_d3dpp.BackBufferWidth = m_disState.getWidth();
        m_d3dpp.BackBufferHeight = m_disState.getHeight();
        m_d3dpp.hDeviceWindow = m_hWnd;

        // create Direct3D device
        HRESULT res;
        res = m_p3d->CreateDevice(
        D3DADAPTER_DEFAULT,
        D3DDEVTYPE_HAL,
        m_hWnd,
        D3DCREATE_HARDWARE_VERTEXPROCESSING,
        &m_d3dpp,
        &m_dRender);
        if (m_dRender == NULL){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: CreateDevice Api (creation direct3d device).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return false;
        }

        // clear the backbuffer to black
        m_dRender->Clear(0, NULL, D3DCLEAR_TARGET, D3DCOLOR_XRGB(0,0,0), 0, 0);

        // create pointer to the back buffer
        m_dRender->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &m_backbuffer);

        // optimize device for 2D render
        m_dRender->SetRenderState(D3DRS_ZENABLE, FALSE); // 3D Cap.
        m_dRender->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE); // 3D Cap.
        m_dRender->SetRenderState(D3DRS_LIGHTING, FALSE); // 3D Cap.
        m_dRender->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

        // initialize Sprite Handler
        HRESULT result = D3DXCreateSprite(m_dRender, &m_sprHndFix);
        if (result != D3D_OK){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: D3DXCreateSprite Api (creation sprite handler).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return false;
        }

        result = D3DXCreateSprite(m_dRender, &m_sprHndTrn);
        if (result != D3D_OK){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: D3DXCreateSprite Api (creation sprite handler).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return false;
        }

        m_isIniteRender = true;
        return true;
    }

    void KGraphicImpl::release(){
        if (!m_isIniteRender)
            return;

        if (m_sprHndFix) m_sprHndFix->Release();
        if (m_sprHndTrn) m_sprHndTrn->Release();
        #ifdef KITE_DEV_DEBUG
        printf("sprite(s) released. |Line: %u |File: %s\n", __LINE__, __FILE__);
        #endif

        if (m_dRender) m_dRender->Release();
        #ifdef KITE_DEV_DEBUG
            printf("render device released. |Line: %u |File: %s\n", __LINE__, __FILE__);
        #endif

        if (m_p3d) m_p3d->Release();
        #ifdef KITE_DEV_DEBUG
            printf("render object released. |Line: %u |File: %s\n", __LINE__, __FILE__);
        #endif

        m_isIniteRender = false;
    }

    bool KGraphicImpl::beginRenderScene(bool useTransformedSprite){
        if (m_isErrorDuring)
            return false;
        // start device
        if (m_dRender->BeginScene() != D3D_OK){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: BeginScene Api. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        // start 2D render
        m_useRotSprite = useTransformedSprite;

        // fix Sprite
        if (m_sprHndFix->Begin(D3DXSPRITE_ALPHABLEND) != D3D_OK){ // MinGW
            #ifdef KITE_DEV_DEBUG
            printf("Error in: Begin Api. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        // rotatable Sprite
        if (!m_useRotSprite)
            return true;
        if (m_sprHndTrn->Begin(D3DXSPRITE_ALPHABLEND) != D3D_OK){ // MinGW
            #ifdef KITE_DEV_DEBUG
            printf("Error in: Begin Api. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        return true;
    }

    bool KGraphicImpl::endRenderScene(){
        // end 2D render
        if (m_sprHndFix->End() != D3D_OK){
            m_dRender->EndScene();
            #ifdef KITE_DEV_DEBUG
            printf("Error in: End Api. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_APIFAIL;
            return false;
        }

        if (m_useRotSprite){
            if (m_sprHndTrn->End() != D3D_OK){
                m_dRender->EndScene();
                #ifdef KITE_DEV_DEBUG
                printf("Error in: End Api. |Line: %u |File: %s\n", __LINE__, __FILE__);
                #endif
                m_isErrorDuring = true;
                m_lastError = KERROR_APIFAIL;
                return false;
            }
        }

        // end device
        if (m_dRender->EndScene() != D3D_OK){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: EndScene Api. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_APIFAIL;
            return false;
        }
        return true;
    }

    bool KGraphicImpl::presentRenderScene(){
        HRESULT hr;
        // swap rendered buffer
        hr = m_dRender->Present(NULL, NULL, NULL, NULL);
        if (hr == D3D_OK) return true;
        if (hr == D3DERR_DEVICELOST){
            #ifdef KITE_DEV_DEBUG
            printf("Messege: device lost. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_DEVLOST;
            return false;
        }
        if (hr == D3DERR_DRIVERINTERNALERROR){
            #ifdef KITE_DEV_DEBUG
            printf("Message: problems in the display adapter. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_DRIVER_ERROR;
            return false;
        }
        if (hr == D3DERR_INVALIDCALL){
            #ifdef KITE_DEV_DEBUG
            printf("Error in: Present Api. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            m_isErrorDuring = true;
            m_lastError = KERROR_APIFAIL;
            return false;
        }
        return false;
    }

    void KGraphicImpl::clearRenderScene(const KCOLOR &color, const KRect<U32> &area){
        m_clearScene.x1 = area.x;
        m_clearScene.y1 = area.y;
        m_clearScene.x2 = area.width;
        m_clearScene.y2 = area.height;
        m_dRender->Clear(1, &m_clearScene, D3DCLEAR_TARGET, (D3DCOLOR)color, 0, 0);
    }

    void KGraphicImpl::clearRenderScene(const KCOLOR &color){
        m_dRender->Clear(0, NULL, D3DCLEAR_TARGET, (D3DCOLOR)color, 0, 0);
    }

    const KTexture *KGraphicImpl::loadTexture(const char *fileName)
    {
        if (!m_isIniteRender){
            #ifdef KITE_DEV_DEBUG
                printf("device not created or not initialized.\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return 0;
        }
        LPDIRECT3DTEXTURE9 pTex;
        D3DXIMAGE_INFO info;
        if (D3DXCreateTextureFromFileEx(m_dRender,
                                        LPSTR(fileName), 0, 0, 1 ,0 ,
                                        D3DFMT_A8R8G8B8, D3DPOOL_MANAGED,
                                        D3DX_FILTER_NONE ,D3DX_FILTER_NONE ,
                                        0 ,&info ,NULL ,&pTex ) != D3D_OK){
            #ifdef KITE_DEV_DEBUG
                printf("Error in: D3DXCreateTextureFromFileExA Api (can't load texture).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return 0;
        }
        return new KTexture((KTEXTURE)pTex, info.Width, info.Height);
    }

    const KTexture *KGraphicImpl::loadTexture(const char *fileName,KCOLOR &color)
    {
        if (!m_isIniteRender){
            #ifdef KITE_DEV_DEBUG
                printf("device not created or not initialized.\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return 0;
        }
        LPDIRECT3DTEXTURE9 pTex;
        D3DXIMAGE_INFO info;
        if (D3DXCreateTextureFromFileEx(m_dRender,
                                        LPSTR(fileName), 0, 0, 1 ,0 ,
                                        D3DFMT_A8R8G8B8, D3DPOOL_MANAGED,
                                        D3DX_FILTER_NONE ,D3DX_FILTER_NONE ,
                                        (D3DCOLOR)color, &info, NULL, &pTex ) != D3D_OK){
            #ifdef KITE_DEV_DEBUG
                printf("Error in: D3DXCreateTextureFromFileExA Api (can't load texture).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return 0;
        }
        return new KTexture((KTEXTURE)pTex, info.Width, info.Height);
    }

    void KGraphicImpl::freeTexture(const KTexture *texture){
        LPDIRECT3DTEXTURE9 pTex = (LPDIRECT3DTEXTURE9) texture->texture; // Crashable when texture deleted once before
        if (pTex != NULL){
            pTex->Release();
        }
        pTex = NULL;
        if (texture != 0){
            delete texture;
        }
        texture = 0;
    }

    bool KGraphicImpl::drawFixSprite(const KSprite &sprite, bool subRect){
        if (!m_isIniteRender){
            #ifdef KITE_DEV_DEBUG
                printf("device not created or not initialized.\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return false;
        }
        m_spritePos.x = sprite.position.x;
        m_spritePos.y = sprite.position.y;
        if (!subRect){
            if (m_sprHndFix->Draw((LPDIRECT3DTEXTURE9)sprite.texture->texture, NULL,
                                   NULL, &m_spritePos,
                                   (D3DCOLOR)sprite.color) == D3D_OK)
                return true;
        }else{
            m_spriteSubRect.top = sprite.subRect.y;
            m_spriteSubRect.left = sprite.subRect.x;
            m_spriteSubRect.bottom = sprite.subRect.width;
            m_spriteSubRect.right = sprite.subRect.height;
            if (m_sprHndFix->Draw((LPDIRECT3DTEXTURE9)sprite.texture->texture, &m_spriteSubRect,
                                   NULL, &m_spritePos,
                                   (D3DCOLOR)sprite.color) == D3D_OK)
                return true;
        }
        #ifdef KITE_DEV_DEBUG
            printf("Error in: Draw Api (can't draw sprite).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
        #endif
        return false;
    }

    bool KGraphicImpl::drawTransformedSprite(const KSprite &sprite, bool subRect){
        if (!m_isIniteRender){
            #ifdef KITE_DEV_DEBUG
                printf("device not created or not initialized.\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return false;
        }
        if (!m_useRotSprite)
            return false;
        m_spritePos.x = sprite.position.x;
        m_spritePos.y = sprite.position.y;
        m_spriteCenter.x = sprite.center.x;
        m_spriteCenter.y = sprite.center.y;
        m_spriteScale.x = sprite.scale.x;
        m_spriteScale.y = sprite.scale.y;

        D3DXMatrixTransformation2D(&m_spriteMat, NULL, 0.0, &m_spriteScale,
                                   &m_spriteCenter, sprite.rotation, NULL);
        if (m_sprHndTrn->SetTransform(&m_spriteMat) != D3D_OK){
            #ifdef KITE_DEV_DEBUG
                printf("Error in: SetTransform Api (can't transform sprite).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
            #endif
            return false;
        }
        if (!subRect){
            if (m_sprHndTrn->Draw((LPDIRECT3DTEXTURE9)sprite.texture->texture, NULL,
                                   NULL, &m_spritePos,
                                   (D3DCOLOR)sprite.color) == D3D_OK)
                return true;
        }else{
            m_spriteSubRect.top = sprite.subRect.y;
            m_spriteSubRect.left = sprite.subRect.x;
            m_spriteSubRect.bottom = sprite.subRect.width;
            m_spriteSubRect.right = sprite.subRect.height;
            if (m_sprHndTrn->Draw((LPDIRECT3DTEXTURE9)sprite.texture->texture, &m_spriteSubRect,
                                   NULL, &m_spritePos,
                                   (D3DCOLOR)sprite.color) == D3D_OK)
                return true;
        }
        #ifdef KITE_DEV_DEBUG
            printf("Error in: Draw Api (can't draw sprite).\nLine: %u\nFile: %s\n", __LINE__, __FILE__);
        #endif
        return false;
    }

    bool KGraphicImpl::deviceLost(){
        if (m_dRender->TestCooperativeLevel() == D3D_OK)
            return true;

        if (m_dRender->TestCooperativeLevel() == D3DERR_DEVICENOTRESET){
            m_deviceIsLost = true;
            m_backbuffer->Release();
            m_sprHndFix->OnLostDevice();
            m_sprHndTrn->OnLostDevice();
            m_d3dpp.BackBufferHeight = m_disState.getHeight();
            m_d3dpp.BackBufferWidth = m_disState.getWidth();
            m_d3dpp.Windowed = (!m_winState.getFullscreen());
            if (m_dRender->Reset(&m_d3dpp) == D3D_OK){
                m_sprHndFix->OnResetDevice();
                m_sprHndTrn->OnResetDevice();
                m_dRender->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &m_backbuffer);
                m_dRender->SetRenderState(D3DRS_ZENABLE, FALSE); // 3D Cap.
                m_dRender->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE); // 3D Cap.
                m_dRender->SetRenderState(D3DRS_LIGHTING, FALSE); // 3D Cap.
                m_dRender->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
                m_deviceIsLost = false;
                return true;
            }
        }
        return false;
    }

    KiteErrorTypes KGraphicImpl::GetLastError(){
        KiteErrorTypes temp = m_lastError;
        m_lastError = KERROR_OK;
        return temp;
    }

    KGraphic *KGraphicImpl::_createInstance(){
        if (m_GraphicImpl != 0){
            #ifdef KITE_DEV_DEBUG
            printf("Message: an graphic instance already exists. |Line: %u |File: %s\n", __LINE__, __FILE__);
            #endif
            return (KGraphic *)m_GraphicImpl;
        }
        m_GraphicImpl = new KGraphicImpl();
        return (KGraphic *)m_GraphicImpl;
    }

    void KGraphicImpl::_destroyInstance(){
        delete m_GraphicImpl;
        m_GraphicImpl = 0;
    }

    KGraphic *CreateGraphic(){
        return KGraphicImpl::_createInstance();
    }

    void DestroyGraphic(){
        KGraphicImpl::_destroyInstance();
    }

}
