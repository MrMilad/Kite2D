/* 
 Kite2D Game Framework.
 Copyright (C) 2010-2014  Milad Rasaneh <milad_rasaneh2000@yahoo.com>

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or 
 any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef KGRAPHICIMPL_H
#define KGRAPHICIMPL_H

#include <cstdio>
#include <d3d9.h>
#include <d3dx9.h>
#include <windows.h>
#include "Kite/graphic/kgraphic.h"

namespace Kite{
    class KGraphicImpl : public KGraphic{
    public:

        /* Initialize and Release Direct3D 9 "Devices" */
        virtual bool initialize(const KWindowState &winState, KDisplayState disState, HWND hWindow); // Initialize Direct3D 9
        virtual void release();

        /* Render Scene Functions */
        virtual bool beginRenderScene(bool useTransformedSprite);
        virtual bool endRenderScene();
        virtual bool presentRenderScene();
        virtual void clearRenderScene(const KCOLOR &color);
        virtual void clearRenderScene(const KCOLOR &color, const KRect<U32> &area);

        /* Texture Operations */
        virtual const KTexture *loadTexture(const char *fileName, KCOLOR &color);
        virtual const KTexture *loadTexture(const char *fileName);
        virtual void freeTexture(const KTexture *texture);

        /* Sprite Operations */
        virtual bool drawFixSprite(const KSprite &sprite, bool subRect);
        virtual bool drawTransformedSprite(const KSprite &sprite, bool subRect);

        virtual KiteErrorTypes GetLastError();

        virtual bool deviceLost();

        // (internal use only)
        static KGraphic *_createInstance();
        static void _destroyInstance();

        // Direct3D 9 Objects
        LPDIRECT3D9 m_p3d; // Direct3D Object
        LPDIRECT3DDEVICE9 m_dRender; // Direct3D Device
        D3DPRESENT_PARAMETERS m_d3dpp;
        LPDIRECT3DSURFACE9 m_backbuffer;
        LPD3DXSPRITE m_sprHndFix; // Sprite Handler - Fixed
        LPD3DXSPRITE m_sprHndTrn; // Sprite Handler - Transformed

        D3DXVECTOR2 m_spriteCenter; // Center of Sprite
        D3DXVECTOR3 m_spritePos; // Position of Sprite
        D3DXVECTOR2 m_spriteScale;
        D3DXMATRIX m_spriteMat; // 2D Transformation Matrix (Transform Sprites)
        RECT m_spriteSubRect; // Subrect for Draw Sprite
        D3DRECT m_clearScene; // Subrect for Clear Scene

        KiteErrorTypes m_lastError; // Stored last error

        /* Counters */
        //U16 m_textureCounte;

        // Constructure member
        KWindowState m_winState; // Window State
        KDisplayState m_disState; // Display State
        HWND m_hWnd;

        bool m_deviceIsLost; // Device State
        bool m_isIniteRender;
        bool m_useRotSprite; // Checking Scalabale Sprite used or not (in render loop)
        bool m_isErrorDuring;

        static KGraphicImpl *m_GraphicImpl;

    private:
        KGraphicImpl();
        ~KGraphicImpl();
    };
}
#endif // KGRAPHICIMPL_H
